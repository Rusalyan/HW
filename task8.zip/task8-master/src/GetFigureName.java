public class GetFigureName  {
    public void getFigureName(Shape shape){
        shape.getName();
    }
}